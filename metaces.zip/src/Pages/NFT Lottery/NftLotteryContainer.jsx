import React from 'react'
import NftLottery from './NftLottery'

const NftLotteryContainer = (props) => {
    return (
        <>
            <NftLottery/>
        </>
    )
}

export default NftLotteryContainer